window.FICTPLAY_CONFIG = {
  SUPABASE_URL: "https://YOUR_PROJECT_ID.supabase.co",
  SUPABASE_ANON_KEY: "YOUR_SUPABASE_ANON_KEY",
  // WARNING: Do not ship OpenAI API keys to the browser in production.
  // Use a server-side proxy. This is only for local testing.
  OPENAI_API_KEY: "",
};
